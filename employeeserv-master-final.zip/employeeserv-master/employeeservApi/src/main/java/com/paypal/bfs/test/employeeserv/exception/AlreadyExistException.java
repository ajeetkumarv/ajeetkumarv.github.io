package com.paypal.bfs.test.employeeserv.exception;

public class AlreadyExistException extends Exception {

	public AlreadyExistException(String msg, Throwable throwable) {
		super(msg, throwable);
	}
	
	public AlreadyExistException(String msg) {
		super(msg);
	}

	@Override
	public String toString() {
		return "AlreadyExistException [msg=" + getMessage() + ", cause=" + getCause() + "]";
	}
	
	
}
