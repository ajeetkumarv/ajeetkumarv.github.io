INSERT INTO employees(id, first_name, last_name)
VALUES(1,'Tom', 'James');
INSERT INTO employees(id, first_name, last_name)
VALUES(2,'Harry', 'Pat');