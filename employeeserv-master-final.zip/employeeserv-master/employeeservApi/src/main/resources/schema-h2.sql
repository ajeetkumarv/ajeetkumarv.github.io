CREATE TABLE employees(
	id BIGINT PRIMARY KEY,
	first_name VARCHAR(30),
	last_name VARCHAR(30),
	date_of_birth date,
	line1 VARCHAR(30),
	line2 VARCHAR(30),
	city VARCHAR(30),
	state VARCHAR(30),
	zip_code VARCHAR(30)
);
CREATE UNIQUE INDEX uq_emp ON employees(first_name, last_name, date_of_birth);