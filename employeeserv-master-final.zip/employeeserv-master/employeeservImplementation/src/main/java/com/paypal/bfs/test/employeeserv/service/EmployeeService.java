package com.paypal.bfs.test.employeeserv.service;

import com.paypal.bfs.test.employeeserv.api.model.Employee;
import com.paypal.bfs.test.employeeserv.exception.AlreadyExistException;

public interface EmployeeService {

	public Employee getEmployee(Integer id);
	public Integer createEmployee(Employee emp) throws AlreadyExistException;
	
}
