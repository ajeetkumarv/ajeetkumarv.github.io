package com.paypal.bfs.test.employeeserv.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import com.paypal.bfs.test.employeeserv.api.EmployeeResource;
import com.paypal.bfs.test.employeeserv.api.model.Employee;
import com.paypal.bfs.test.employeeserv.exception.AlreadyExistException;
import com.paypal.bfs.test.employeeserv.service.EmployeeService;

/**
 * Implementation class for employee resource.
 */
@RestController
public class EmployeeResourceImpl implements EmployeeResource {

	@Autowired
    private EmployeeService empService;
	
    @Override
    public ResponseEntity<Employee> employeeGetById(String id) {
    		Employee employee = empService.getEmployee(parseId(id));
    		return new ResponseEntity<>(employee, HttpStatus.OK);
    }
    
	@Override
	public ResponseEntity<String> employeeCreate(Employee emp) throws AlreadyExistException {
		String msg = validateEmployee(emp);
		
		if (msg.length() > 0) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(msg);
		}
		
		Integer rowCount = empService.createEmployee(emp);
		return new ResponseEntity<String>(rowCount + " record(s) creation successful", HttpStatus.CREATED);
	}
	
	/* Exception handlers  */
	@ExceptionHandler(NumberFormatException.class)
    public ResponseEntity<String> idFormatCheck(NumberFormatException e) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("ID should be a number");
    }
	
	@ExceptionHandler(InvalidFormatException.class)
    public ResponseEntity<String> idFormatCheck(InvalidFormatException e) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Date of birth format should be yyyy-MM-dd");
    }
    
    @ExceptionHandler(EmptyResultDataAccessException.class)
    public ResponseEntity<String> noEmployeeFound(EmptyResultDataAccessException e) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No Employee Found");
    }
	
	@ExceptionHandler(AlreadyExistException.class)
    public ResponseEntity<String> employeeExist(AlreadyExistException e) {
        return ResponseEntity.status(HttpStatus.ALREADY_REPORTED).body(e.getMessage());
    }
	
	private Integer parseId(String id) {
		return Integer.valueOf(id);
	}
	private String validateEmployee(Employee emp) {
		String msg = "";
		if (emp.getDateOfBirth() == null) {
			msg = msg + "Date of birth is required. format yyyy-MM-dd";
		}
		if (emp.getFirstName() == null || "".equals(emp.getFirstName())
				|| emp.getLastName() == null || "".equals(emp.getLastName())) {
			msg = msg + "\n" + "First name and Last name both are required";
		}
		return msg;
	}
}
