package com.paypal.bfs.test.employeeserv.service.impl;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import com.paypal.bfs.test.employeeserv.api.model.Address;
import com.paypal.bfs.test.employeeserv.api.model.Employee;
import com.paypal.bfs.test.employeeserv.exception.AlreadyExistException;
import com.paypal.bfs.test.employeeserv.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
    private JdbcTemplate jtm;
	
	@Override
	public Employee getEmployee(Integer id) {
		
		String sql = "SELECT * FROM employees WHERE id = ?";

        return jtm.queryForObject(sql, new Object[]{id}, new RowMapper<Employee>() {

			@Override
			public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {
				Employee e = new Employee();
				Address addr = new Address();
				e.setAddress(addr);
				
				e.setId(rs.getInt("id"));
				e.setFirstName(rs.getString("first_name"));
				e.setLastName(rs.getString("last_name"));
				e.setDateOfBirth(rs.getDate("date_of_birth"));
				addr.setLine1(rs.getNString("line1"));
				addr.setLine2(rs.getNString("line2"));
				addr.setCity(rs.getNString("city"));
				addr.setState(rs.getNString("state"));
				addr.setZipcode(rs.getNString("zip_code"));
				
				return e;
			}
        	
		});
	}

	@Override
	public Integer createEmployee(Employee emp) throws AlreadyExistException {
		
		detailsExistCheck(emp);
		
		String sql = "insert into employees "
				+ "(id, first_name, last_name, date_of_birth, line1, line2, city, state, zip_code)"
				+ " values (?,?,?,?,?,?,?,?,?)";
		
		Address addr = emp.getAddress();
		addr = addr == null ? new Address() : addr;
		Integer resultCount = null;
		try {
			resultCount = jtm.update(sql, emp.getId(), emp.getFirstName(), emp.getLastName(), emp.getDateOfBirth(),
				addr.getLine1(), addr.getLine2(), addr.getCity(), addr.getState(), addr.getZipcode()
				);
		} catch(DuplicateKeyException e) {
			throw new AlreadyExistException("Error inserting data, first name, last name and date of birth already exist", e);
		}
		return resultCount;
	}

	private void detailsExistCheck(Employee emp) throws AlreadyExistException {
		idExistCheck(emp.getId());
	}

	private void idExistCheck(Integer id) throws AlreadyExistException {
		try {
			Employee e = getEmployee(id);
			throw new AlreadyExistException("ID " + id + " already exist");
		} catch(EmptyResultDataAccessException e) {
			System.out.println(id + "id exist test pass, not found");
		}
	}

}
