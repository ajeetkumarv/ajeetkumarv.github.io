package test;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.paypal.bfs.test.employeeserv.EmployeeservApplication;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = EmployeeservApplication.class)
@WebAppConfiguration
public class EmployeeResourceImplTest {
	protected MockMvc mvc;
	@Autowired
	WebApplicationContext webApplicationContext;
	@Before
	public void setUp() {
	      mvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
	}

	@Test
	public void createEmployeeTest() throws Exception {
		String uri = "/v1/bfs/employees/create";
	      String inputJson = "{\"id\":\"4\",\"first_name\":\"Peters\",\"last_name\":\"paster\",\"date_of_birth\":\"2018-05-06\"}";
	      MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.post(uri)
	         .contentType(MediaType.APPLICATION_JSON_VALUE)
	         .content(inputJson)).andReturn();
	      
	      int status = mvcResult.getResponse().getStatus();
	      Assert.assertEquals(201, status);
	      String content = mvcResult.getResponse().getContentAsString();
	      Assert.assertEquals(content, "1 record(s) creation successful");
	}
	
	@Test
	public void createEmployeeDOBFormatTest() throws Exception {
		String uri = "/v1/bfs/employees/create";
	      String inputJson = "{\"id\":\"5\",\"first_name\":\"Tim\",\"last_name\":\"paster\"}";
	      MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.post(uri)
	         .contentType(MediaType.APPLICATION_JSON_VALUE)
	         .content(inputJson)).andReturn();
	      
	      int status = mvcResult.getResponse().getStatus();
	      Assert.assertEquals(400, status);
	      String content = mvcResult.getResponse().getContentAsString();
	      Assert.assertEquals(content, "Date of birth is required. format yyyy-MM-dd");
	}


	@Test
	public void employeeGetByIdTest() throws Exception {
		String id = "1";
		String uri = "/v1/bfs/employees/" + id;
	      MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE)).andReturn();
	      
	      int status = mvcResult.getResponse().getStatus();
	      Assert.assertEquals(200, status);
	      String content = mvcResult.getResponse().getContentAsString();
	      
	      Assert.assertEquals(content, "{\"id\":1,\"first_name\":\"Tom\",\"last_name\":\"James\",\"address\":{}}");
	}
	
	@Test
	public void employeeGetByIdNotFoundTest() throws Exception {
		String id = "100";
		String uri = "/v1/bfs/employees/" + id;
	      MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE)).andReturn();
	      
	      int status = mvcResult.getResponse().getStatus();
	      Assert.assertEquals(404, status);
	      String content = mvcResult.getResponse().getContentAsString();
	      
	      Assert.assertEquals(content, "No Employee Found");
	}
	
	@Test
	public void employeeGetByIdNumberFormatExceptionTest() throws Exception {
		String id = "A100";
		String uri = "/v1/bfs/employees/" + id;
	      MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE)).andReturn();
	      
	      int status = mvcResult.getResponse().getStatus();
	      Assert.assertEquals(400, status);
	      String content = mvcResult.getResponse().getContentAsString();
	      
	      Assert.assertEquals(content, "ID should be a number");
	}
	
}
