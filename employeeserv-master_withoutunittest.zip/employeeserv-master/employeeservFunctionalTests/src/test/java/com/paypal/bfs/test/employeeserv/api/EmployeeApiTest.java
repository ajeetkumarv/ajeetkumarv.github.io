package com.paypal.bfs.test.employeeserv.api;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class EmployeeApiTest {

	@Test
	public void contextLoads() {
	}

	/*
	 * @Autowired private EmployeeResource controller;
	 * 
	 * @Test public void contexLoads() throws Exception {
	 * assertThat(controller).isNotNull(); }
	 */
	
}
